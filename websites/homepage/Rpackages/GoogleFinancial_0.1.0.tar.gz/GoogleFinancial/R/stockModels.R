#########################################################################################
#Google-Financial package                                                               #
#########################################################################################
#                                                                                       #
# (c) 2011 Danny Arends                                                                 #
#                                                                                       #
# Needs: RCurl package                                                                  #
# Contains:                                                                             #
# lCorporation, lCorporationYear                                                        #
# lCorporation.model, lCorporationYear.model                                            #
#########################################################################################

#Model a stock price Version 0.1
#Using a lineair model over time
lCorporation.model <- function(corporation, column="Open"){
  lin_comp <- 1:nrow(corporation$data)
  model <- lm(corporation$data[,column]~lin_comp)
  attr(corporation,paste("model",column,sep="",collapse="_")) <- model
  corporation
}

#Prediction function using lCorporation.model
lCorporation <- function(corporation, column="Open", verbose=FALSE){
  modelname <- paste("model",column,sep="",collapse="_")
  if(is.null(attr(corporation,modelname))){
    if(verbose) cat("no model, building lineair model\n")
    corporation <- lCorporation.model(corporation,column)
  }
  model <- attr(corporation,modelname)
  lin_comp <- 1:(nrow(corporation$data)+104)
  corporation$prediction <- cbind(corporation$prediction,model[[1]][1] + model[[1]][2]*lin_comp)
  corporation
}

#Model a stock price Version 0.2
#Using a year as covariate
#Using a lineair model over time
lCorporationYear.model <- function(corporation, column="Open"){
  lin_effect <- 1:nrow(corporation$data)
  model <- lm(corporation$data[,column]~ as.numeric(year.corporation(corporation)) + lin_effect)
  attr(corporation,paste("model",column,sep="",collapse="_")) <- model
  corporation
}

#Prediction function belonging to effectsOnStock
lCorporationYear <- function(corporation, column="Open",verbose=FALSE){
  modelname <- paste("model",column,sep="",collapse="_")
  if(is.null(attr(corporation,modelname))){
    if(verbose) cat("no model, building lineair model\n")
    corporation <- lCorporationYear.model(corporation,column)
  }
  model <- attr(corporation,modelname)
  lin_comp <- 1:(nrow(corporation$data)+104)
  year_comp <- as.numeric(c(year.corporation(corporation),rep(2012,52),rep(2013,52)))
  corporation$prediction <- cbind(corporation$prediction,model[[1]][1] + model[[1]][2] * year_comp + model[[1]][3]*lin_comp)
  corporation
}
