#########################################################################################
#Google-Financial package                                                               #
#########################################################################################
#                                                                                       #
# (c) 2011 Danny Arends                                                                 #
#                                                                                       #
# Needs: RCurl package                                                                  #
# Contains:                                                                             #
# storeFinancialData                                                                    #
# searchGoogle, parseSearchReturn                                                       #
#########################################################################################

#Basic Search Google function
searchGoogle <- function(searchterm="AMS:AGN",year=2010,verbose=FALSE){
  require("RCurl")
  querystring <- paste("http://www.google.com/finance/historical?q=",searchterm,"&startdate=Jan+1,+",year,"&enddate=Dec+31,+",year,"&histperiod=weekly&num=52",sep="")
  if(verbose) cat(querystring,"\n",sep="")
  HTMLdata <- getURL(querystring)
  invisible(HTMLdata)
}

#Parse the return from the search Query from Google Financial
parseSearchReturn <- function(HTMLdata){
  possible <- regexpr("<td class=\"lm\">(.+?)<td class=\"rgt rm\">",HTMLdata)
  mydata <- NULL
  while(possible > 0){
    mydata <- rbind(mydata,strsplit(gsub(",","",gsub("\n","\t",gsub("<td class=\"rgt\">","",substr(HTMLdata,possible[[1]]+15,possible[[1]]+(attr(possible,"match.length")-21))))),"\t")[[1]])
    HTMLdata <- substr(HTMLdata,possible[[1]]+attr(possible,"match.length")-1,nchar(HTMLdata))
    possible <- regexpr("<td class=\"lm\">(.+?)<td class=\"rgt rm\">",HTMLdata)
  }
  formatted <- cbind(as.numeric(mydata[,2]),as.numeric(mydata[,3]),as.numeric(mydata[,4]),as.numeric(mydata[,5]))
  rownames(formatted) <- mydata[,1]
  colnames(formatted) <- c("Open","High","Low","Close")
  invisible(formatted)
}

#downloadStockPrices: the requested data from Google Financial (and cache it onto disk)
downloadStockPrices <- function(x, period=1999:2011,verbose=FALSE){
  if(any(class(x)=="corporations")){
    data <- x$corporations
  }else{
    if(any(class(x)=="corporation")){
      data <- as.matrix(t(x$id[-1]))
      rownames(data) <- x$id[1]
      results <- vector("list", 1)
    }else{
      stop("Input should have class \"corporations\" or  \"corporation\".")
    }
  }
  cnt <- 0
  results <- vector("list", nrow(data))
  for(c in 1:nrow(data)){
    cat("-Starting analysis: ",rownames(data)[c],"\n")
    companydata <- NULL
    for(year in period){
      if(verbose) cat("--Year: ",year, " from ",min(period)," - ",max(period))
      if(file.exists(filename <- gsub(":","_",paste(year,":",data[c,1],".txt",sep="")))){
        if(verbose) cat(" data cached...\n")
        aa <- as.matrix(read.table(file=filename,header=TRUE))
      }else{
        aa <- parseSearchReturn(searchGoogle(data[c,1],year))
        if(nrow(aa) > 3){
          if(verbose) cat(" data available...\n")
          write.table(aa,file=filename)
          cnt = cnt+1;
        }else{
          if(verbose) cat(" no data...\n")
        }
      }
      companydata <- rbind(aa,companydata)
    }
    if(nrow(companydata) > 3){
      correctorder <- NULL
      for(o in 1:nrow(companydata)){
        correctorder <- rbind(correctorder,companydata[nrow(companydata)+(1-o),])
      }
      results[[c]] <- correctorder
      rownames(results[[c]]) <- rownames(companydata)[nrow(companydata):1]
      attr(results[[c]],"Name") <- rownames(data)[c]
      attr(results[[c]],"ID") <- data[c,1]
      attr(results[[c]],"StockExchance") <- data[c,2]
      write.table(correctorder,file=gsub(":","_",paste("S_",data[c,1],".txt",sep="")))
    }
  }
  cat("Downloaded ",cnt," reports\n")
  if(any(class(x)=="corporations")){
    x$data <- results
  }else{
    x$data <- results[[1]]
  }
  invisible(x)
}
