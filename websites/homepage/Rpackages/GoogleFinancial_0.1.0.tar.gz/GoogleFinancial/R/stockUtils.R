#########################################################################################
#Google-Financial package                                                               #
#########################################################################################
#                                                                                       #
# (c) 2011 Danny Arends                                                                 #
#                                                                                       #
# Needs: RCurl package                                                                  #
# Contains:                                                                             #
# read.corporations get.corporation                                                     #
# get.corporations.std , day.corporation, month.corporation, year.corporation           #
#########################################################################################

read.corporations <- function(file="corporations.csv"){
  data <- NULL
  data$corporations <- as.matrix(read.csv(file=file, row.names=1, header=TRUE, colClasses=c("character","character")))
  class(data) <- c("corporations",class(data))
  data
}

get.corporations.std <- function(){
  data <- NULL
  data$corporations <- rbind(
    c("Adobe Systems Inc.","NASDAQ:ADBE","NASDAQ"),
    c("Altera Corporation","NASDAQ:ALTR","NASDAQ"),
    c("Amazone","NASDAQ:AMZN","NASDAQ"),
    c("Apple Inc.", "NASDAQ:AAPL","NASDAQ"),
    c("BioGen","NASDAQ:BIIB","NASDAQ"),
    c("Cisco Systems","NASDAQ:CSCO","NASDAQ"),
    c("Cognizant Corporation","NASDAQ:CTSH","NASDAQ"),
    c("Citrix Systems","NASDAQ:CTXS","NASDAQ"),
    c("DELL","NASDAQ:DELL","NASDAQ"),
    c("EBAY","NASDAQ:EBAY","NASDAQ"),
    c("Ericsson Company","NASDAQ:ERICY","NASDAQ"),
    c("Google Inc.", "NASDAQ:GOOG","NASDAQ"),
    c("Intel Corporation","NASDAQ:INTC","NASDAQ"),
    c("Liberty Media Int.","NASDAQ:LBTYA","NASDAQ"),
    c("Maxim Integrated","NASDAQ:MXIM","NASDAQ"),
    c("Microsoft Corporation","NASDAQ:MSFT","NASDAQ"),
    c("Oracle Corporation","NASDAQ:ORCL","NASDAQ"),
    c("Microchip Tech.","NASDAQ:MCHP","NASDAQ"),
    c("Sears Holdings Corporation","NASDAQ:SHLD","NASDAQ"),
    c("Yahoo","NASDAQ:YHOO","NASDAQ"),
    c("Citigroup Inc.","NYSE:C","NYSE"),
    c("Coca-Cola Corporation","NYSE:KO","NYSE"),
    c("3M Corporation","NYSE:MMM","NYSE"),
    c("Alcoa Inc.","NYSE:AA","NYSE"),
    c("Exxon Mobile","NYSE:XOM","NYSE"),
    c("General Electric","NYSE:GE","NYSE"),
    c("Wal-Mart","NYSE:WMT","NYSE"),
    c("J.P. Morgan Chase","NYSE:JPM","NYSE"),
    c("Boeing Corporation","NYSE:BA","NYSE"),
    c("IBM","NYSE:IBM","NYSE"),
    c("Johnson&Johnson","NYSE:JNJ","NYSE"),
    c("MCDonalds Corporation","NYSE:MCD","NYSE"),
    c("Du Pont","NYSE:DD","NYSE"),
    c("Verizon Communications","NYSE:VZ","NYSE"),
    c("Honeywell Int.","NYSE:HON","NYSE"),
    c("Caterpillar Inc.","NYSE:CAT","NYSE"),
    c("Procter & Gamble","NYSE:PG","NYSE"),
    c("Walt Disney Corporation","NYSE:DIS","NYSE"),
    c("Home Depot inc.","NYSE:HD","NYSE"),
    c("American Express","NYSE:AXP","NYSE"),
    c("Hewlett-Packard","NYSE:HPQ","NYSE"),
    c("Aegon N.V.", "AMS:AGN","AEX"),
    c("Koninklijke Ahold N.V.", "AMS:AH","AEX"),
    c("Akzo Nobel N.V.", "AMS:AKZA","AEX"),
    c("ASML Holding N.V.", "AMS:ASML","AEX"),
    c("ArcelorMittal", "AMS:MT","AEX"),
    c("Koninklijke DSM N.V.", "AMS:DSM","AEX"),
    c("Heineken N.V.", "AMS:HEIA","AEX"),
    c("ING Group N.V.", "AMS:INGA","AEX"),
    c("Koninklijke KPN N.V.", "AMS:KPN","AEX"),
    c("Koninklijke Philips Electronics N.V.", "AMS:PHIA","AEX"),
    c("Randstad Holding N.V.", "AMS:RAND","AEX"),
    c("Reed Elsevier N.V.", "AMS:REN","AEX"),
    c("Royal Dutch Shell", "AMS:RDSA","AEX"),
    c("TNT N.V.", "AMS:TNT","AEX"),
    c("TomTom N.V.", "AMS:TOM2","AEX"),
    c("Unilever N.V.", "AMS:UNA","AEX")
  )
  rownames(data$corporations) <- data$corporations[,1]
  data$corporations <- data$corporations[,-1]
  colnames(data$corporations) <- c("ID","Stock exchange")
  class(data) <- c("corporations",class(data))
  data
}

get.corporation <-  function(corporations,name="Unilever N.V."){
  if(!any(class(corporations)=="corporations")) stop("Input should have class \"corporations\".")
  if(is.numeric(name) && name <= nrow(corporations$corporations)){
    id <- name;
  }else{
    if(!any(rownames(corporations$corporations)==name)){
      if(!any(corporations$corporations[,1]==name)){
        stop("Unknown company Name/ID.")
      }else{
      id <- which(corporations$corporations[,1]==name)
      }
    }else{
      id <- which(rownames(corporations$corporations)==name)
    }
  }
  corporation <- NULL
  corporation$id <- c(rownames(corporations$corporations)[id],corporations$corporations[id,])
  names(corporation$id) <- c("Name","ID","Stock Exchange")
  if(!is.null(corporations$data)){
    corporation$data <- corporations$data[[id]]
  }
  if(!is.null(corporations$predictions) &&!is.null(corporations$predictions[[id]])){
    corporation$prediction <- corporations$predictions[[id]]
  }
  class(corporation) <- c("corporation",class(corporation))
  invisible(corporation)
}

#Helper functions to get time of samples / Model from company object
month.corporation <- function(corporation){ 
  unlist(lapply(strsplit(rownames(corporation$data)," "),function(x){x[1]})) 
}

day.corporation <- function(corporation){ 
  unlist(lapply(strsplit(rownames(corporation$data)," "),function(x){x[2]})) 
}

year.corporation <- function(corporation){ 
  unlist(lapply(strsplit(rownames(corporation$data)," "),function(x){x[3]})) 
}

