#########################################################################################
#Google-Financial package                                                               #
#########################################################################################
#                                                                                       #
# (c) 2011 Danny Arends                                                                 #
#                                                                                       #
# Needs: RCurl package                                                                  #
# Contains:                                                                             #
# monthsoftheyear                                                                       #
#########################################################################################

#Help function listing all the short names of months in the year
monthsoftheyear <- function(){
  c("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec")
}

#Load a daily weather dataset from file or URL
#Data from: "http://climexp.knmi.nl/data/teca162.dat" or "weather_nld_daily.txt"
#load.weather.daily <- function(filename="weather_nld_daily.txt"){
#  cat("-Start loading:",filename,"\n")
#  rawdata <- as.matrix(read.table(filename,header=FALSE,skip=5))
#  
#  m <- 1
#  for(x in monthsoftheyear()){
#    rawdata[which(rawdata[,2]==m),2] <- x
#    m <- m+1
#  }
#
#  mynames <- paste(rawdata[,2],rawdata[,3],rawdata[,1])
#  daily_data <- as.numeric(rawdata[,4])
#  names(daily_data) <- mynames
#  daily_data
#}

#Load a monthly weather dataset from file or URL
## Data from: "http://climexp.knmi.nl/data/ta72605.dat" or "weather_usa.txt"
#load.weather.monthly <- function(filename="weather_usa.txt"){
#  cat("-Start loading:",filename,"\n")
#  rawdata <- as.matrix(read.table(filename,row.names=1,header=FALSE,skip=5))
#  colnames(rawdata) <- monthsoftheyear()
#  rawdata[which(rawdata < -900)] <- NA
#  rawdata
#}
  
#Plot a monthly overview of a monthly weather dataset
#plot.weather.month <- function(monthlydata){
#  plot(c(1,12),c(-50,50),type="n",main="Weather Monthly Data",ylab="Temp (C)",xlab="Month",xaxt="n")
#  cols <- gray.colors(nrow(monthlydata))
#  for(x in 1:nrow(monthlydata)){
#    points(monthlydata[x,],type='l',col=cols[x])
#  }
#  axis(1,1:12,monthsoftheyear())
#}

#Plot a year overview of a monthly weather dataset
#plot.weather.year <- function(monthlydata){
#  plot(c(1,nrow(monthlydata)),c(-50,50),type="n",main="Weather Monthly Data",ylab="Temp (C)",xlab="Years",xaxt="n")
#  cols <- gray.colors(12)
#  for(x in 1:12){
#    points(monthlydata[,x],type='l',col=cols[x])
#  }
#  axis(1,1:nrow(monthlydata),rownames(monthlydata))
#}

#Create a predictor from monthly weather data
#Can only be used with monthly weather data
#predictor.monthly <- function(weatherdata, companiedata){
#  temp <- NULL
#  for(x in 1:nrow(companiedata)){
#    mydate <- strsplit(rownames(companiedata)[x]," ")[[1]]
#    temp <- c(temp,weatherdata[mydate[3],mydate[1]])
#  }
#  temp
#}

#Create a predictor from daily weather data
#Can only be used with daily data
#predictor.daily <- function(weatherdaily, companiedata){
#  weatherdaily[rownames(companiedata)]
#}

#Estimate effects of the weather files we downloaded on the target Stock Price (Open, Close, High, Low)
#estimate.effects <- function(weatherdata,companiesdata,target="Open",predictor=predictor.daily){
#  effects_m <- NULL
#  for(x in 1:length(companiesdata)){
#    avg_temp <- predictor(weatherdata,companiesdata[[x]])
#    myanova <- anova(lm(companiesdata[[x]][,target] ~ as.numeric(year(companiesdata[[x]])) * avg_temp))
#    effects_m <- rbind(effects_m,c(myanova[[5]][1],myanova[[5]][2],myanova[[5]][3]))
#  }
#  rownames(effects_m) <- getCompanies(companiesdata)
#  colnames(effects_m) <- c("Year","Weather","Year:Weather")
#  attr(effects_m,"StockPrice") <- target
#  effects_m
#}

#Basic test-routine to test the weather analysis
#weatheranalysis.test <- function(){
#  setwd(tempdir())

  ## Data from: "http://climexp.knmi.nl/data/ta72605.dat" or "weather_usa.txt"
 # data_usa <- load.weather.monthly("http://climexp.knmi.nl/data/ta72605.dat")
  ## Data from: "http://climexp.knmi.nl/data/ta6260.dat" or "weather_nld.txt"
 # data_nld <- load.weather.monthly("http://climexp.knmi.nl/data/ta6260.dat")
  #Data from: "http://climexp.knmi.nl/data/teca162.dat" or "weather_nld_daily.txt"
#  data_nld_daily <- load.weather.daily("http://climexp.knmi.nl/data/teca162.dat")

 # plot.weather.year(data_nld)
 # Sys.sleep(1.0)
  #plot.weather.month(data_usa)
  
 # companies <- companiesTEST()
 # companiesdata <- storeFinancialData(companies,period=2000:2010)
 # cat(" -Outcome Daily NLD weather:","\n")
#  print(estimate.effects(data_nld_daily,companiesdata,"High") < 0.01)
#  cat(" -Outcome Monthly NLD weather:","\n")
#  print(estimate.effects(data_nld_daily,companiesdata,"Low") < 0.01)
#  cat(" -Outcome Monthly USA weather:","\n")
#  print(estimate.effects(data_usa,companiesdata,"Open",predictor.monthly) < 0.01)
#}
