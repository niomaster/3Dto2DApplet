#########################################################################################
#Google-Financial package                                                               #
#########################################################################################
#                                                                                       #
# (c) 2011 Danny Arends                                                                 #
#                                                                                       #
# Needs: RCurl package                                                                  #
# Contains:                                                                             #
# plot.corporations, plot.corporation                                                   #
# plotcorporation.internal                                                              #
#########################################################################################

#Plot the overview of the corporations
plot.corporations <- function(x, ...){
  plot(as.factor(x$corporations[,2]), ...)
}

#Plot the overview of a single corporation (prices and predictions)
plot.corporation <- function(x, ...){
  prediction <- x$prediction
  data <- x$data
  if(is.null(prediction)){
    plotcorporation.internal(data,c("High","Low"),0)
  }else{
    plot(c(1,nrow(data)+104),c(min(c(data,prediction)),max(c(data,prediction))),xlab=paste(rownames(data)[1],"to",rownames(data)[nrow(data)]),ylab="",type="n",main=attr(data,"Name"))
    points(c(data[,2],rep(NA,104)),col="red",type="s")
    points(c(data[,3],rep(NA,104)),col="green",type="s")
    points(prediction[,2],col="black",type="l",lwd=2,lty=2)
    points(prediction[,3],col="black",type="l",lwd=2,lty=2)
    legend("topright",c("high","low","prediction (H)","prediction (L)"),lwd=c(1,1,2,2),lty=c(1,1,2,2),col=c("red","green","black","black"))
  }
}

#Internal function used to plot the companies stocks prices
plotcorporation.internal <- function(x, show=c("Open","High","Low","Close"), predictionsize=c(0,104)){
  plot(c(1,nrow(x)+predictionsize[1]),c(min(x,0),max(x)),xlab=paste(rownames(x)[1],"to",rownames(x)[nrow(x)]),ylab="",type="n",main=attr(x,"Name"))
  colors <- rainbow(length(show))
  item <- 1
  for(stock in show){
    points(c(x[,stock],rep(NA,predictionsize[1])),col=colors[item],lwd=2,type="s")
    item <- item+1
  }
  legend("bottomright",c(show),lwd=2,col=colors)
}
