#########################################################################################
#Google-Financial package                                                               #
#########################################################################################
#                                                                                       #
# (c) 2011 Danny Arends                                                                 #
#                                                                                       #
# Needs: RCurl package                                                                  #
# Contains:                                                                             #
# print.corporations                                                                    #
#########################################################################################

print.corporations <-function(x,...){
  cat("Corporations per stock exchange\n")
  print(summary(as.factor(x$corporations[,2])))
  data_cnt <- 0
  prediction_cnt <- 0
  if(is.null(x$data)){
    cat("- Stock price data NOT found, use: downloadStockPrices\n")
  }else{
    for(cnt in 1:length(x$data)){
      corporation <- get.corporation(x,cnt)
      if(!is.null(corporation$data)) data_cnt <- data_cnt + 1
      if(!is.null(corporation$prediction)) prediction_cnt <- prediction_cnt + 1
    }
    if(data_cnt!=0){
      cat("- Stock price data for",data_cnt,"/",length(x$data),"found\n")
      if(prediction_cnt!=0){  
        cat("- Stock price predictions for",prediction_cnt,"/",length(x$data),"found\n")
      }else{
        cat("- Stock price predictions NOT found, use: predictStockPrices\n")
      }
    }else{
      cat("- Stock price data NOT found, use: downloadStockPrices\n")
    }
  }
}

print.corporation <- function(x, ...){
  cat("Corporation:",x$id["Name"],"(",x$id["ID"],") on the",x$id["Stock Exchange"]," stock exchange\n")
  if(is.null(x$data)){
    cat("- Stock price data NOT found, use: downloadStockPrices\n")
  }else{
    cat("- ",nrow(x$data),"stock price data records found, years:")
    cat(" ",paste(unique(year.corporation(x)),sep=","),"\n")
    cat("Yearly means:\n")
    cat("Year\tOpen\tHigh\tLow\tClose\n")
    for(year in unique(year.corporation(x))){
      cat(year,round(apply(x$data[which(year.corporation(x)==year),],2,mean),digits=1),"\n",sep="\t")
    }
  }
}