#
#
# zzz.R
#
# copyright (c) 2010, Danny Arends
# last modified mrt, 2010
# first written mrt, 2010
# 
# R functions: .First.lib
#
#

.First.lib <- function(lib, pkg) library.dynam("iqtl", pkg, lib)

# end of zzz.R
