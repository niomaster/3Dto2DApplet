#####################################################################
 # 
 # scanRF.R
 #
 # Copyright (c) 2009 Danny Arends
 # Last modified Mrt, 2009
 # First written Mrt, 2009
 #
 # scanRF
 # Contains: scanRF - 	N-Dimensional phenotype additive interactions scanning methode for QTL mapping using the randomForest algorithm
 #			 			made as a training excersice in QTL mapping in RIL/BC and F2 crosses
 #						Usefull for fast lowlevel (markerwise) data exploration for QTL mapping experiments
 # Depends: R/QTL package
 # 			randomForest
 # 
 #
#####################################################################

unittest.scanRF <- function(){
	#require(qtl)
	#require(randomForest)
	#data(listeria)
	#data(hyper)	
	#aaa <- scanRF(listeria)					#Listeria dataset Phenotype1
	#aaa	<- scanRF(hyper)					#Hypertensia datset Phenotype1
}

mapRF <- function(data,model){
	require(randomForest)
	temp <- cbind(data$phenotype,t(data$genotypes))
	colnames(temp)[1] <- "phenotype"
	rf <- randomForest(phenotype ~ ., data=temp, importance=T,proximity=T)
	importance(rf)[,1]/max(abs(importance(rf)[,1]))
}



scanRF <- function(cross=NULL,pheno.col=1,filename=NULL,...){
	require(qtl)
	require(randomForest)
	cross <- qtl::fill.geno(cross)

	#Handle phenotype from R/QTL
	pheno <- NULL
	
	if (length(pheno.col) > 1){
		pheno <- cross$pheno[,pheno.col]
		n.traits <- ncol(pheno)
	}else{
		if(qtl::nphe(cross) > pheno.col && pheno.col >0){
			pheno <- qtl::pull.pheno(cross)[pheno.col]
			n.traits <- 1
		}else{
			stop("ERROR: Wrong phenotype..") 
		}
	}
	#Handle genotypes
	data <- NULL
	for(i in 1:length(cross$geno)){
		#cat("Chromosome: ",i,"\n")
		data <- cbind(data,cross$geno[[i]]$data)
	}
	names <- NULL
	#Name the phenotypes
	xnam <- NULL
	for(i in 1:n.traits){
		xnam <- c(xnam,paste("P", pheno.col[i], sep=""))
	}
	names <- xnam
	for(i in 1:dim(data)[2]){
		#Rename markers so we don't have naming problems
		names <- c(names,paste("M",i,sep=""))
	}
	#cat(names,"\n")
	data <- cbind(pheno,data)
	colnames(data) <- names
	#remove all missing phenotypes (we filled in the geno's)
	data <- na.exclude(data)
	if(n.traits==1){
		howmany <-1
	}else{
		howmany <- n.traits + 1
	}
	op <- par(mfrow = c(n.traits + 1,1))
	xnames <- NULL
	for(i in 1:(howmany)){
		if(i == howmany){
			xnames = xnam
			temp <- data
		}else{
			xnames <- c(paste("P", pheno.col[i], sep=""))
			temp <- data[,-which(!(xnam==xnames))]
		}
		rf <- randomForest((fmla <- as.formula(paste(paste(xnames, collapse= "+"), " ~ ."))) , data=temp, importance=T,proximity=T,...)
	
		resrf <- importance(rf)[,1]/max(importance(rf)[,1])
		resrf <- cbind(resrf,importance(rf)[,2]/max(importance(rf)[,2]))
		
		plot(resrf[,1],type='l', main=paste("RF QTL profile",paste(xnames, collapse= "+")," ~ Markers"), xlab="Markers", ylab="Importance",col="blue",lwd=2)
		lines(resrf[,2],type='l',col="black",lwd=1)
		grid()
		if(n.traits==1){
			plot(rf,col="red",lwd=1)
			grid()
		}
		if(!is.null(filename)){
			cat(resrf[,1], resrf[,2],"\n", file=filename,sep="\t", append=T)
		}
	}
	print(rf)
	list(rf,data)
}
