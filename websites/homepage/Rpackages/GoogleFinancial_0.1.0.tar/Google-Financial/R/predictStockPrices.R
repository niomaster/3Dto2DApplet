#########################################################################################
#Google-Financial package                                                               #
#########################################################################################
#                                                                                       #
# (c) 2011 Danny Arends                                                                 #
#                                                                                       #
# Needs: RCurl package                                                                  #
# Contains:                                                                             #
# predictStockPrices                                                                    #
#########################################################################################

#Predict stocks prices 2 years into the future
#Using effectsOnStock
#Plots a graph using plotStock
predictStockPrices <- function(corporations, predictionFUN=lCorporation, plot=FALSE, verbose=FALSE){
  if(!any(class(corporations)=="corporations")) stop("Input should have class \"corporations\".")
  if(is.null(corporations$data)) stop("No financial data. Download financial data using the \"downloadStockPrices\" function.")
  buy <- NULL
  buynames <- NULL
  dontbuy <- NULL
  dontbuynames <- NULL
  corporations$predictions <- vector("list", length(corporations$data))
  for(cnt in 1:length(corporations$data)){
    corporation <- get.corporation(corporations,cnt)
    if(verbose) cat("Corporation: ",attr(corporation$data,"Name"),"\n")
    corporation$prediction <- NULL
    for(column in colnames(corporation$data)){
      corporation <- predictionFUN(corporation,column)
    }
    if(nrow(corporation$prediction) > 156){
      corporations$predictions[[cnt]] <- corporation$prediction
      last_year_avg <- mean(corporation$data[(nrow(corporation$data)-52):nrow(corporation$data),1])
      predicted_average <- mean(corporation$prediction[(nrow(corporation$prediction)-104):nrow(corporation$prediction),1])
      if(last_year_avg < predicted_average){
        buy <- rbind(buy,c(round(last_year_avg,2),round(predicted_average,2)))
        buynames <- c(buynames,attr(corporation$data,"Name"))
      }
      if(last_year_avg > predicted_average){
        dontbuy <- rbind(dontbuy,c(round(last_year_avg,2),round(predicted_average,2)))
        dontbuynames <- c(dontbuynames,attr(corporation$data,"Name"))
      }
      if(plot) plot(corporation)
    }else{
      cat("Skipping: ",attr(corporation$data,"Name"),"\n")
    }
  }
  #Format the names nicely
  if(!is.null(buy)){
    colnames(buy) <- c("Last Year","Predicted")
    rownames(buy) <- buynames
  }
  if(!is.null(dontbuy)){
    colnames(dontbuy) <- c("Last Year","Predicted")
    rownames(dontbuy) <- dontbuynames
  }
  corporations$actions <- list(buy,dontbuy)
  names(corporations$actions) <- c("Rise","Fall")
  invisible(corporations)
}
