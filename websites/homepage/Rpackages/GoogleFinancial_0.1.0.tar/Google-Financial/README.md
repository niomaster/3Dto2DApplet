The GoogleFinancial package
=================
This package provides a wrapper to download financial data from [Google Finance](http://www.google.com/finance "Google Finance"). 
It provides tools to model the downloaded financial data. This package provides automated loading of datasets 
from [Google Finance](http://www.google.com/finance "Google Finance"). It aims to predict stock prices 
for the upcoming 2 years . Furthermore the packages allows for exploration of the downloaded data like 
discovery of batch / localized effects. To provide easy data downloading and managment a pre-made list 
of companies from AEX, DowJones and NasDaQ is provided. However it is always possible to define your 
own set of companies / indices to monitor and study.

Dependencies
------------
R software environment from [www.r-project.org](http://www.r-project.org/ "www.r-project.org") and the RCurl 
package from [www.omegahat.org/RCurl](http://www.omegahat.org/RCurl/ "www.omegahat.org/RCurl")

Installation
------------
Prepare your environment by following these two steps:

- Download and Install the R environment
- Install the RCurl package into the R environment

Then install into R by using (from a terminal / commanline):

    $ git clone git://github.com/DannyArends/Google-Financial.git  # Download the repository
    $ R CMD INSTALL Google-Financial                               # Install the package

Optionally you can install the pre-build packages by downloading the appropriate 
package for your operating system. 

Starting
--------
Load the library in the R interface by the following command (in R):
    
    $ > library(GoogleFinancial)                                   # Load the library
    $ > ?GoogleFinancial                                           # Show the help

To download stock data:
    
    $ > data(corporations)                                         # Companies
    $ > corporations                                               # Show the data
    $ Corporations per stock exchange           
    $    AEX NASDAQ   NYSE
    $     16     20     21   
    $ - Stock price data NOT found, use: downloadStockPrices
    $ > corporations <- downloadStockPrices(corporations)          # Download from Google

To predict and plot the predictions of the upcoming 2 year period:

    $ > corporations <- predictStockPrices(corporations)           # Predict stock prices for the next 2 years
    $ > corporations                                               # Show the data
    $    AEX NASDAQ   NYSE
    $     16     20     21   
    $ - Stock price data for 57 / 57 found
    $ - Stock price predictions for 57 / 57 found
    $ > corporations$actions                                       # Show the predictions
    $ $Rise                                                        # Predicted to RISE
    $                                Last Year Predicted
    $ AEX Index                         343.25    400.23
    $ NYSE Euronext                      30.83     37.71
    $ $Fall                                                        # Predicted to FALL
    $                                Last Year Predicted
    $ SSE Composite Index              2777.33   2566.35

GoogleFinancial TODO
--------------------

- Better modelling
- Use different models comparitive
- Meta analysis of the entire dataset
- More default company lists

Contributing
------------

Want to contribute? Great!

1. Clone it.
2. Compile it.
3. Run it.
4. Modify some code. (Search -> 'TODO')
5. Go back to 2, or
6. Submit a patch

You can also just post comments on code / commits.

Danny Arends

Disclaimer
----------
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License,
version 3, as published by the Free Software Foundation.

This program is distributed in the hope that it will be useful,
but without any warranty; without even the implied warranty of
merchantability or fitness for a particular purpose.  See the GNU
General Public License, version 3, for more details.

A copy of the GNU General Public License, version 3, is available
at [http://www.r-project.org/Licenses/GPL-3](http://www.r-project.org/Licenses/GPL-3 "GPL-3 Licence")
Copyright (c) 2010 Danny Arends
