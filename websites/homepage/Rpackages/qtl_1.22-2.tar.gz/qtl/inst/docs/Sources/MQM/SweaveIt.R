Stangle(file="MQM-tour.Rnw")
Sweave(file="MQM-tour.Rnw",pdf=FALSE)
q("no")
